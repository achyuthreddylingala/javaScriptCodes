//11.	Write JavaScript code that reverses a given array in place (without creating a new array) using a for loop.
function arrayReverse(){
    let list = [1,2,3,4,5];  
    let length = list.length;
    console.log("Before Swapping:" +list);
    for(let i=0;i<Math.floor(list.length/2);i++){// Here, I have devided the list by 2 as the arrayReverse function is only trave
    let temp = list[i];
    list[i] = list[length - 1 - i];
    list[length - 1 - i] = temp;   
    }
    console.log("After Swapping:" + list);
}
arrayReverse();
