//Develop a program that converts a given number to words (e.g., 123 to "one hundred twenty-three") using loops and arrays for digit mapping.
//code:
function numberToWords(number) {
    const ones = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
    const teens = ['ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
    const tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

    let words = '';

    if (number === 0) {
        return ones[number];
    }

    if (number >= 100) {
        words += ones[Math.floor(number / 100)] + ' hundred ';
        number %= 100;
    }

    if (number >= 20) {
        words += tens[Math.floor(number / 10)] + ' ';
        number %= 10;
    }

    if (number >= 10 && number <= 19) {
        words += teens[number - 10];
    } else if (number >= 1 && number <= 9) {
        words += ones[number];
    }

    return words.trim();
}
// Example usage
console.log(numberToWords(123)); // Output: "one hundred twenty-three"
console.log(numberToWords(456)); // Output: "four hundred fifty-six"
console.log(numberToWords(789)); // Output: "seven hundred eighty-nine"
console.log(numberToWords(12));  // Output: "twelve"
console.log(numberToWords(20));  // Output: "twenty"
