//Write a function that generates the nth Fibonacci number using memoization to optimize performance.
//code:
function fibonacci(n, memo = {}) {
    if (n in memo) {
        return memo[n];
    }
    if (n <= 1) {
        return n;
    }
    memo[n] = fibonacci(n - 1, memo) + fibonacci(n - 2, memo);
    return memo[n];
}
let n = 10; 
console.log("The " + n + "th Fibonacci number is: " + fibonacci(n));
