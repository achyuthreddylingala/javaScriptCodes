function factorial() {
    let number = 5; 
    let fact = 1;
    let i = 1;
    while (i < number) { 
        fact = fact * i;
        i++;
    }
    console.log("The factorial of " + number + " is " + fact);
}
factorial();
