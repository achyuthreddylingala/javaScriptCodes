//Create JavaScript code that simulates a basic stopwatch allowing users to start, stop, and reset.
//code:
class Stopwatch {
    constructor() {
        this.startTime = 0;
        this.running = false;
        this.elapsed = 0;
    }

    start() {
        if (!this.running) {
            this.startTime = Date.now() - this.elapsed;
            this.running = true;
            this.timer = setInterval(() => {
                this.elapsed = Date.now() - this.startTime;
                this.print();
            }, 100);
        }
    }

    stop() {
        if (this.running) {
            clearInterval(this.timer);
            this.running = false;
        }
    }

    reset() {
        this.elapsed = 0;
        this.print();
    }

    print() {
        let minutes = Math.floor(this.elapsed / 60000);
        let seconds = ((this.elapsed % 60000) / 1000).toFixed(3);
        console.log(`${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`);
    }
}
const stopwatch = new Stopwatch();
stopwatch.start(); // Start the stopwatch
setTimeout(() => {
    stopwatch.stop(); // Stop the stopwatch after 3 seconds
}, 3000);
setTimeout(() => {
    stopwatch.start(); // Start the stopwatch again after 2 seconds
}, 5000);
setTimeout(() => {
    stopwatch.reset(); // Reset the stopwatch after 1 second
}, 7000);
