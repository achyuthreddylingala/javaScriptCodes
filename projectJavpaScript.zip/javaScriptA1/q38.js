//Write JavaScript function that checks if a given year is a leap year using the ternary operator.
//code:
function isLeapYear(year) {
    return (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)) ? true : false;
}
let year = 2024;
console.log(year + ' is a leap year: ' + isLeapYear(year));
year = 2021;
console.log(year + ' is a leap year: ' + isLeapYear(year));
