//Develop a program that calculates the sum of all prime numbers up to a given number using the Sieve of Eratosthenes algorithm.
//code:
function sumOfPrimesUpToN(n) {
    // Create an array to store whether each number is prime or not
    const isPrime = new Array(n + 1).fill(true);

    // Set 0 and 1 as non-prime
    isPrime[0] = false;
    isPrime[1] = false;

    // Sieve of Eratosthenes algorithm to find prime numbers
    for (let i = 2; i * i <= n; i++) {
        if (isPrime[i]) {
            // Mark multiples of i as non-prime
            for (let j = i * i; j <= n; j += i) {
                isPrime[j] = false;
            }
        }
    }

    // Calculate the sum of prime numbers
    let sum = 0;
    for (let i = 2; i <= n; i++) {
        if (isPrime[i]) {
            sum += i;
        }
    }

    return sum;
}

// Example usage
const n = 10;
console.log("Sum of all prime numbers up to", n, "is:", sumOfPrimesUpToN(n)); // Output: 17 (2 + 3 + 5 + 7)
