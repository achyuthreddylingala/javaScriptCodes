/*9.	Write a program that generates a random number between 1 and 10 and prompts the user to guess the number. Provide feedback if the guess is too high or too low using a do-while loop*/
function randomNumberGenerator() {
    let number = Math.floor(Math.random() * 10) + 1; // Generate random number between 1 and 10
    let userInput;

    do {
        userInput = parseInt(prompt("Enter your guess:"));
        if (userInput > number) {
            window.alert("The guessed number is too high");
        } else if (userInput < number) {
            window.alert("The guessed number is too low");
        }
    } while (userInput !== number);

    window.alert("Congratulations! You guessed the correct number: " + number);
}

randomNumberGenerator();
