/*25.	Write a program that generates a random number between 1 and 100 and prompts the user to guess the number. Provide feedback if the guess is too high or too low using a while loop.*/
//code:
function guessNumberGame() {
    const randomNumber = Math.floor(Math.random() * 100) + 1; // Generate random number between 1 and 100
    let guess = 0;
    let attempts = 0;

    console.log("Welcome to the Number Guessing Game!");
    console.log("I have selected a random number between 1 and 100. Can you guess it?");

    while (guess !== randomNumber) {
        guess = parseInt(prompt("Enter your guess (between 1 and 100):"));

        if (isNaN(guess) || guess < 1 || guess > 100) {
            console.log("Please enter a valid number between 1 and 100.");
        } else if (guess < randomNumber) {
            console.log("Too low! Try again.");
            attempts++;
        } else if (guess > randomNumber) {
            console.log("Too high! Try again.");
            attempts++;
        }
    }

    console.log(`Congratulations! You guessed the correct number ${randomNumber} in ${attempts} attempts.`);
}

// Start the game
guessNumberGame();
