//Write a JavaScript program to find the sum of all even numbers between 1 and 100 using a for loop.
//Code:
function evenChecker(){
    let sum = 0;
    for(let i =0; i <=100; i++){
        if(i%2==0){
            sum = sum + i;
        }
    }
    console.log("The sum of all even numbers from  1 to 100 is " + sum);
}
evenChecker();