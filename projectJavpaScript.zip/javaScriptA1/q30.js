//30. Create JavaScript code that calculates the factorial of a number using recursion.
//code:
function factorial() {
    let number = 6;
    let fact = 1; 
    if (number === 0 || number === 1) {
        return 1; 
    } else {
        for (let i = 2; i <= number; i++) {
            fact *= i; 
        }
        console.log("The factorial of " + number + " is " + fact);
    }
}

factorial();

