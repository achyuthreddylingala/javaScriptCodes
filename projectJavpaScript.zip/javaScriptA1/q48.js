//Develop a program that finds the factorial of a number using memoization to optimize performance.
//code:
// Create a memoization object to store previously computed results
let memo = {};

// Function to find the factorial of a number using memoization
function factorial(n) {
    // Base case: If n is 0 or 1, return 1
    if (n === 0 || n === 1) {
        return 1;
    }

    // If the result for n is already cached, return it
    if (memo[n]) {
        return memo[n];
    }

    // Calculate the factorial recursively and store the result in memoization object
    memo[n] = n * factorial(n - 1);
    return memo[n];
}

// Example usage
let number = 5;
console.log("Factorial of", number, "is:", factorial(number));
