//1.	Write a JavaScript program to check if a given number is even or odd using an if statement.
let number = 35;

if (number % 2 === 0) {
    console.log("The number " + number + " is Even");
} else {
    console.log("The number " + number + " is Odd");
}


