//24.	Create JavaScript code that checks if a number is a prime number using a while loop.
//code:
function isPrime(number) {
    let i = 2;
    if (number <= 1) {
        return false;
    }
    while (i <= Math.sqrt(number)) {
        if (number % i === 0) {
            return false; 
        }
        i++;
    }

    return true; 
}
let numberToCheck = 17; 
if (isPrime(numberToCheck)) {
    console.log(numberToCheck + " is a prime number.");
} else {
    console.log(numberToCheck + " is not a prime number.");
}
