//Write a function that converts a decimal number to binary using repeated division by 2 and a while loop.
//code
function decimalToBinary(decimalNumber) {
    let binaryString = ''; 
    while (decimalNumber > 0) {
        let remainder = decimalNumber % 2;
        binaryString = remainder + binaryString; 
        decimalNumber = Math.floor(decimalNumber / 2); 
    }
    return binaryString;
}
let decimalNumber = 25; 
let binaryEquivalent = decimalToBinary(decimalNumber);
console.log("Binary equivalent of " + decimalNumber + " is: " + binaryEquivalent);
