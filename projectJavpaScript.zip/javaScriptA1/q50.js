//Write a program that checks if a given number is a Harshad number (a number that is divisible by the sum of its own digits) using loops and arithmetic operations.
//code:
//a number that is divisible by the sum of its own digits is called a HarshadNumber.
// Function to calculate the sum of digits of a number
function sumOfDigits(number) {
    let sum = 0;
    while (number > 0) {
        sum += number % 10;
        number = Math.floor(number / 10);
    }
    return sum;
}

// Function to check if a number is a Harshad number
function isHarshadNumber(number) {
    let sum = sumOfDigits(number);
    return number % sum === 0;
}

// Example usage
let number = 18;
if (isHarshadNumber(number)) {
    console.log(number + " is a Harshad number.");
} else {
    console.log(number + " is not a Harshad number.");
}
