//Write JavaScript code that checks if a given string is an anagram of another string using arrays and loops.
//code:
/*An anagram is a word or phrase formed by rearranging the letters of another word or phrase, using all the original letters exactly once. In simpler terms, two words are considered anagrams if they contain the same letters with the same frequency, but in a different order.*/
function isAnagram(str1, str2) {
    str1 = str1.replace(/\s/g, '').toLowerCase();
    str2 = str2.replace(/\s/g, '').toLowerCase();
    if (str1.length !== str2.length) {
        return false;
    }
    let arr1 = str1.split('').sort();
    let arr2 = str2.split('').sort();
    for (let i = 0; i < arr1.length; i++) {
        if (arr1[i] !== arr2[i]) {
            return false;
        }
    }

    return true;
}
let string1 = "listen";
let string2 = "silent";

if (isAnagram(string1, string2)) {
    console.log(string1 + " and " + string2 + " are anagrams.");
} else {
    console.log(string1 + " and " + string2 + " are not anagrams.");
}
