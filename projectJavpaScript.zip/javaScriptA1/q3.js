//3.	Write JavaScript code that compares two numbers and outputs the larger one without using if-else statements. 
let number1 = parseInt(prompt("Enter the first number:"));
let number2 = parseInt(prompt("Enter the second number:"));

let largerNumber = Math.max(number1, number2);

console.log("The larger number is " + largerNumber);

