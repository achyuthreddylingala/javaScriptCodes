//15.	Create a program that prints the multiplication table of a given number using a for loop.
function multiplicationTable(){
    let number = 2;
    for(let i =1; i<=10;i++){
    let  multiplication = number * i;
    console.log("The multiplication table of 2 is:SSSS "+number+"*"+i+"="+ multiplication);
    }
}
multiplicationTable();