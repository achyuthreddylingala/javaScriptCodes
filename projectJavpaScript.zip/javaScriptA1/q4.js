//4.	Develop a program that determines if a given year is a leap year using nested if statements.
//A leap year occurs every 4 years
function leapYearChecker(){
    var year = parseInt(prompt('Enter the year:'));
    if(year %4 ==0){
        if (year %100 !=0) {
            console.log("The year "+ year + " is a leap year");
        } else{     
            if (year %400 == 0) {
                console.log("The year "+ year + " is a leap year");
            }else{
                console.log("The year "+ year + " is not a leap year");
    }
        }
        }else{
            console.log("The year "+ year + " is not a leap year");     
        }  
}
leapYearChecker();