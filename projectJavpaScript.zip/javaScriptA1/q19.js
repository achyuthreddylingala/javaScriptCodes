//19.	Write a program that checks if a given string is a palindrome using a for loop.
//code:
//I was stuck with the previous question similar to palindrome concept. Can you please help me with concept mam.