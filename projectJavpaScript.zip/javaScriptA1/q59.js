//Write a program that checks if a given number is a strong number (a number whose sum of factorial of digits is equal to the number itself) using loops and arithmetic operations.
//code:
// Function to calculate the factorial of a number
function factorial(n) {
    if (n === 0 || n === 1) {
        return 1;
    }
    let result = 1;
    for (let i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

// Function to calculate the sum of factorial of digits of a number
function sumOfFactorialOfDigits(number) {
    let sum = 0;
    let temp = number;
    while (temp > 0) {
        const digit = temp % 10;
        sum += factorial(digit);
        temp = Math.floor(temp / 10);
    }
    return sum;
}

// Function to check if a given number is a strong number
function isStrongNumber(number) {
    return sumOfFactorialOfDigits(number) === number;
}

// Example usage
const number = 145;
if (isStrongNumber(number)) {
    console.log(number + " is a strong number.");
} else {
    console.log(number + " is not a strong number.");
}
