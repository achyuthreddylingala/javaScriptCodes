//16.	Write JavaScript code to find the largest element in an array using a for loop.
//code:
function findLargestElement() {
    let array = [5, 8, 3, 11, 6, 2, 9];  
    if (array.length === 0) {
        return "Array is empty.";
    }  
    let max = array[0]; 
    
    for (let i = 1; i < array.length; i++) {
        if (array[i] > max) {
            max = array[i]; 
        }
    }  
    return max;
}
let largestElement = findLargestElement(); 
console.log("The largest element in the array is: " + largestElement);
