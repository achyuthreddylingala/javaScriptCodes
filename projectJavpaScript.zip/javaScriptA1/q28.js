//Develop JavaScript code that checks if a given number is a perfect number (a positive integer that is equal to the sum of its proper divisors) using a for loop.
//code:
function isPerfectNumber(number) {
    let sum = 0; 
    for (let i = 1; i < number; i++) {
        if (number % i === 0) {
            sum += i;
        }
    }
    return sum === number;
let num = 28; 
if (isPerfectNumber(num)) {
    console.log(num + " is a perfect number.");
} else {
    console.log(num + " is not a perfect number.");
}
}
