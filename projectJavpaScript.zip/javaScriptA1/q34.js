//34. Develop JavaScript code that sorts an array of numbers using the bubble sort algorithm.
//code:
function bubbleSort(arr) {
    const n = arr.length;
    for (let i = 0; i < n - 1; i++) {
        for (let j = 0; j < n - 1 - i; j++) {
            if (arr[j] > arr[j + 1]) {
                let temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    return arr;
}
let numbers = [5, 3, 8, 2, 1, 4];
console.log("Original array:", numbers);
console.log("Sorted array:", bubbleSort(numbers));
