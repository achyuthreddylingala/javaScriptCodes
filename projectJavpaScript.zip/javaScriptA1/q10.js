//10.	Develop a JavaScript program that calculates the sum of all numbers from 1 to 100 using a for loop.
function calculator(){
    var sum = 0;
    for(var i=0;i<=100;i++){
        sum = (sum + i);
            window.alert("the sum of the number from 1 to 100 is:" + sum);
    }
}
calculator();