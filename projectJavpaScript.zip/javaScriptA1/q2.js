//2.	Create a program that prompts the user to enter their age and then outputs whether they are eligible to 
//vote (18 or older) using an if-else statement.
function voteEligibility() {
    let age = parseInt(prompt("Please enter your age:"));

    if (age >= 18) {
        console.log("The person is eligible to vote");
    } else {
        console.log("The person is not eligible to vote");
    }
}

voteEligibility();
//Note: Hello, I dont exactly know the reason but the code waas woeking fine while I was tryibg to run it in the console of my browser but it was not running in the terminal, May be it was due to the environment variables set up.
