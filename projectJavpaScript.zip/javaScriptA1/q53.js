//Create JavaScript code that implements the quicksort algorithm to sort an array of numbers efficiently.
//code:
function quicksort(array) {
    if (array.length <= 1) {
        return array;
    }

    const pivot = array[Math.floor(array.length / 2)];
    const left = [];
    const right = [];

    for (let i = 0; i < array.length; i++) {
        if (i === Math.floor(array.length / 2)) {
            continue; // Skip the pivot element
        }
        if (array[i] < pivot) {
            left.push(array[i]);
        } else {
            right.push(array[i]);
        }
    }

    return [...quicksort(left), pivot, ...quicksort(right)];
}

// Example usage
const unsortedArray = [3, 1, 5, 4, 2];
console.log("Unsorted Array:", unsortedArray);
const sortedArray = quicksort(unsortedArray);
console.log("Sorted Array:", sortedArray);
