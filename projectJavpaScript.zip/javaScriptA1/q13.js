//13.	Develop a program that converts a temperature from Celsius to Fahrenheit and vice versa using a switch statement.

function fahrenheitToCelsius(fahrenheit) {
    let subtracted = fahrenheit - 32;
    let celsius = subtracted * (5 / 9);
    return celsius;
}
let fahrenheitTemperature = 68; 
let celsiusTemperature = fahrenheitToCelsius(fahrenheitTemperature);
console.log(fahrenheitTemperature + "°F is equal to " + celsiusTemperature.toFixed(2) + "°C");
