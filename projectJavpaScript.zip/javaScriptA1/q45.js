//Create JavaScript code that implements a binary search algorithm to find a specific element in a sorted array.
//code:
function binarySearch(arr, target) {
    let left = 0;
    let right = arr.length - 1;

    while (left <= right) {
        // Calculate the middle index
        let mid = Math.floor((left + right) / 2);

        // If the target is found at the middle index, return the index
        if (arr[mid] === target) {
            return mid;
        }

        // If the target is greater than the middle element, search the right half of the array
        if (arr[mid] < target) {
            left = mid + 1;
        }
        // If the target is smaller than the middle element, search the left half of the array
        else {
            right = mid - 1;
        }
    }

    // If the target is not found in the array, return -1
    return -1;
}

// Example usage
let arr = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20];
let target = 14;
let index = binarySearch(arr, target);

if (index !== -1) {
    console.log("Element", target, "found at index", index);
} else {
    console.log("Element", target, "not found in the array.");
}
