//7.	Develop a program that counts the number of even and odd numbers in an array using a for loop and if-else statements.
function numChecker(){
    let list = prompt("Enter an array separated by commas:").split(',').map(Number);
    let len = list.length;
    let countOdd = 0;
    let countEven = 0;
    for(let i = 0; i < len; i++){
        if(list[i] % 2 === 0){
            countEven++;
        } else {
            countOdd++;
        }
    }
    console.log("Number of even numbers: " + countEven);
    console.log("Number of odd numbers: " + countOdd);
}
numChecker();
