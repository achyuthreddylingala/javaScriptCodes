//21.	Create a program that checks if a number is a perfect square using a while loop.
function isPerfectSquare(number) {
    let i = 1;    
    while (i * i <= number) { 
        if (i * i === number) { 
            return true; 
        }
        i++; 
    }
   
    return false; 
}
let num = 25; 
if (isPerfectSquare(num)) {
    console.log(num + " is a perfect square.");
} else {
    console.log(num + " is not a perfect square.");
}
