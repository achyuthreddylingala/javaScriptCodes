//14.	Write JavaScript code that checks if a given number is a prime number using nested if-else statements.
function isPrime() {
    let number = 17; 
    // There are few rules where we consider the number to be not a prime number 
    // 1. the number should not be less than one
    // 2. the numbers should not be divisible by any other numbers from 2 till itself and it should not be a perfect square
    if (number < 2) { 
        // Writing the conditions for the code to check for a prime number using an if else loop
        return false; // This part of the loop will return false if the number is less than 2.
    }
    for (let i = 2; i <= Math.sqrt(number); i++) { 
        if (number % i === 0) {
            return false; // If the number is divisible by any other number, it's not prime
        }
    }
    // If none of the above conditions met then it's a prime number and hence it returns true.
    return true; 
}

if (isPrime() === true) {
    console.log("The number is Prime");
} else {
    console.log("The number is not prime");
}

