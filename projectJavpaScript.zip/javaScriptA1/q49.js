//Develop a program that calculates the sum of digits of factorial of a given number using loops and arithmetic operations.
//code:
// Function to calculate the factorial of a number
function factorial(n) {
    if (n === 0 || n === 1) {
        return 1;
    }
    let result = 1;
    for (let i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

// Function to calculate the sum of digits of a number
function sumOfDigits(number) {
    let sum = 0;
    while (number > 0) {
        sum += number % 10;
        number = Math.floor(number / 10);
    }
    return sum;
}

// Function to calculate the sum of digits of factorial of a given number
function sumOfDigitsOfFactorial(n) {
    let factorialResult = factorial(n);
    return sumOfDigits(factorialResult);
}

// Example usage
let number = 5;
console.log("Sum of digits of factorial of", number, "is:", sumOfDigitsOfFactorial(number));
