function facttorial(){
    let number = 6;
    let fact = 1;
    for(i=1;i<=number; i++){
        fact = fact*i;
    }window.alert("the factprial of a "+number+" is "+fact);
}
facttorial();