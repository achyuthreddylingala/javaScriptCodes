//5.	Create a JavaScript program that converts a numeric grade to a letter grade (A, B, C, D, or F) using if-else if statements.
function gradeConverter(){
    var grade = parseInt(prompt("Enter the number of marks:"));
    if(grade >= 90){
        window.alert(grade + " is a Grade A");
    }else if(grade >=80 && grade < 90){
        window.alert(grade + " is a Grade B");
    }else if(grade>=70 && grade <80){
        window.alert(grade + " is a Grade C");
    }else if(grade >=60 && grade<70){
        window.alert(grade + " is a Grade D");
    }else{
        window.alert(grade + " is an F (Fail)");
    }
}
gradeConverter();