//Develop a program that calculates the sum of digits of a given number until it becomes a single-digit number (digital root) using recursion.
//code:
function digitalRoot(number) {
    if (number < 10) {
        return number; // Base case: If the number is already a single-digit, return it
    }
    let sum = 0;
    while (number > 0) {
        sum += number % 10; // Add the last digit to the sum
        number = Math.floor(number / 10); // Remove the last digit
    }
    return digitalRoot(sum); // Recursively call digitalRoot with the sum
}

// Example usage
const number = 987654321; // Given number
console.log("Digital root of", number, "is:", digitalRoot(number));
