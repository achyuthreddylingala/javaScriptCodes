//Write a program that calculates the sum of squares of all numbers from 1 to a given number using recursion.
//code:
function sumOfSquares(n) {
    // Base case: If n is 0, return 0
    if (n === 0) {
        return 0;
    }
    // Recursive case: Calculate the sum of squares of numbers from 1 to n-1 and add n^2
    return sumOfSquares(n - 1) + (n * n);
}

// Example usage
let number = 5;
console.log("Sum of squares from 1 to " + number + ":", sumOfSquares(number));
