//Write a program that checks if a given number is a narcissistic number (a number that is equal to the sum of its own digits raised to the power of the number of digits) using loops and arithmetic operations.
//code:
function isNarcissisticNumber(number) {
    let strNumber = number.toString();
    let numDigits = strNumber.length;
    let sum = 0;
    for (let digit of strNumber) {
        let digitValue = parseInt(digit);
        sum += Math.pow(digitValue, numDigits);
    }
    return sum === number;
}
let number = 153;
console.log(number + " is a narcissistic number: " + isNarcissisticNumber(number));

number = 1634;
console.log(number + " is a narcissistic number: " + isNarcissisticNumber(number));

number = 9474;
console.log(number + " is a narcissistic number: " + isNarcissisticNumber(number));

number = 123;
console.log(number + " is a narcissistic number: " + isNarcissisticNumber(number));
