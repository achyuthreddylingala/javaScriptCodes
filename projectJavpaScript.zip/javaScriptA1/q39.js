//Create a program that calculates the sum of digits of a given number using recursion.
//code:
function sumOfDigits(number) {
    if (number < 10) {
        return number;
    }
    return number % 10 + sumOfDigits(Math.floor(number / 10));
}
let number = 12345;
console.log("Sum of digits of " + number + " is: " + sumOfDigits(number));
