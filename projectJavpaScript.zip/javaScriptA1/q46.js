//Develop a program that converts a decimal number to hexadecimal and vice versa using loops and arithmetic operations.
//code:
// Function to convert decimal to hexadecimal
function decimalToHexadecimal(decimal) {
    let hexadecimal = "";
    while (decimal > 0) {
        // Get the remainder when dividing by 16 (hexadecimal base)
        let remainder = decimal % 16;

        // Convert the remainder to hexadecimal representation
        let hexDigit = remainder < 10 ? remainder : String.fromCharCode('A'.charCodeAt(0) + remainder - 10);

        // Prepend the hexadecimal digit to the result
        hexadecimal = hexDigit + hexadecimal;

        // Reduce the decimal number by dividing it by 16
        decimal = Math.floor(decimal / 16);
    }
    return hexadecimal || "0"; // Return "0" if the input is 0
}

// Function to convert hexadecimal to decimal
function hexadecimalToDecimal(hexadecimal) {
    let decimal = 0;
    for (let i = 0; i < hexadecimal.length; i++) {
        // Get the decimal value of the current hexadecimal digit
        let digitValue = parseInt(hexadecimal[i], 16);

        // Multiply the current decimal value by 16 (hexadecimal base) and add the digit value
        decimal = decimal * 16 + digitValue;
    }
    return decimal;
}

// Example usage
let decimalNumber = 255;
let hexadecimalNumber = decimalToHexadecimal(decimalNumber);
console.log("Decimal:", decimalNumber, "Hexadecimal:", hexadecimalNumber);

let hexadecimalString = "FF";
let convertedDecimal = hexadecimalToDecimal(hexadecimalString);
console.log("Hexadecimal:", hexadecimalString, "Decimal:", convertedDecimal);
