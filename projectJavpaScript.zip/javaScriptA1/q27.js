//Create a program that determines if a given string is a pangram (contains every letter of the alphabet at least once) using an array and a for loop.
//code:
// A pangram is string which should contain all the letters from the english alphabet
function pangram(){
    let alphabet = 'abcdefghijklmnopqrstuvwxyz';
    let lowercaseInput = inputString.toLowerCase();
    for (let i = 0; i < alphabet.length; i++) {
        if (lowercaseInput.indexOf(alphabet[i]) === -1) {
            return false; 
        }
    }
    return true; 
}
let inputString = "The quick brown fox jumps over the lazy dog";
if (isPangram(inputString)) {
    console.log("The input string is a pangram.");
} else {
    console.log("The input string is not a pangram.");
}