//6. Write JavaScript code that checks if a given string is palindrome or not using a while loop.
//The function takes in a string as an  
//argument and returns true if the string is a
//palindrome, otherwise it returns false. 
function isPalindrome(){
    let input = prompt( "Enter a word: ");
    reversedString = " ";
}
//I am stuck withis question can you please help me with this!