//Develop a program that simulates a simple calculator with basic arithmetic operations (+, -, *, /) using functions and switch statements.
//code:
function calculator() {
    let firstNumber = parseInt(prompt("Enter the first number"));
    let secondNumber = parseInt(prompt("Enter the second number"));
    let operation = parseInt(prompt("What do you want to do?\n1. Addition\n2. Subtraction\n3. Division\n4. Multiplication"));

    let result;
    switch (operation) {
        case 1:
            result = firstNumber + secondNumber;
            console.log("Result of Addition: " + result);
            break;
        case 2:
            result = firstNumber - secondNumber;
            console.log("Result of Subtraction: " + result);
            break;
        case 3:
            result = firstNumber / secondNumber;
            console.log("Result of Division: " + result);
            break;
        case 4:
            result = firstNumber * secondNumber;
            console.log("Result of Multiplication: " + result);
            break;
        default:
            console.log("Invalid operation selected.");
    }
}

calculator();
