//Write a program to change the color of background color randomly.
//code:
function changeBackgroundColor() {
    // Generate random values for red, green, and blue components
    const red = Math.floor(Math.random() * 256);
    const green = Math.floor(Math.random() * 256);
    const blue = Math.floor(Math.random() * 256);
    // Construct a CSS color string
    const color = `rgb(${red}, ${green}, ${blue})`;
    // Apply the new color to the background
    document.body.style.backgroundColor = color;
}
// Call the function to change the background color initially
changeBackgroundColor();
// Example: Change the background color every 3 seconds
setInterval(changeBackgroundColor, 3000);
