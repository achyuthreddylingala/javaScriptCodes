//Write a program that checks if a given string is an Armstrong number (a number that is equal to the sum of its own digits raised to the power of the number of digits) using loops and arithmetic operations.
//code:
function isArmstrongNumber(str) {
    let number = parseInt(str);
    let numDigits = str.length;
    let sum = 0;
    for (let digit of str) {
        let digitValue = parseInt(digit);
        sum += Math.pow(digitValue, numDigits);
    }
    return sum === number;
}
let number = "153"; 
console.log(number + " is an Armstrong number: " + isArmstrongNumber(number));

number = "371";
console.log(number + " is an Armstrong number: " + isArmstrongNumber(number));

number = "9474";
console.log(number + " is an Armstrong number: " + isArmstrongNumber(number));

number = "123";
console.log(number + " is an Armstrong number: " + isArmstrongNumber(number));



