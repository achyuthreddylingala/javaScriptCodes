//17.	Develop a program that calculates the average of numbers in an array using a for loop.
//code:
