//Create a program that finds and prints all prime numbers up to a given number using the Sieve of Eratosthenes algorithm.
//code:
function sieveOfEratosthenes(n) {
    let primes = new Array(n + 1).fill(true);
    primes[0] = primes[1] = false;
    for (let i = 2; i * i <= n; i++) {
        if (primes[i]) {
            for (let j = i * i; j <= n; j += i) {
                primes[j] = false;
            }
        }
    }
    let primeNumbers = [];
    for (let i = 2; i <= n; i++) {
        if (primes[i]) {
            primeNumbers.push(i);
        }
    }
    return primeNumbers;
}
let n = 300; 
let primes = sieveOfEratosthenes(n);
console.log("Prime numbers up to " + n + " are: " + primes.join(", "));
