//Create a JavaScript program that simulates a basic ATM machine, allowing users to check balance, withdraw money, and deposit money
//code:
// Define initial balance
let balance = 1000;
function checkBalance() {
    console.log("Your current balance is: $" + balance);
}
function withdraw(amount) {
    if (amount > balance) {
        console.log("Insufficient funds. Your balance is: $" + balance);
    } else {
        balance -= amount;
        console.log("Withdrawal successful. Remaining balance is: $" + balance);
    }
}
function deposit(amount) {
    balance += amount;
    console.log("Deposit successful. Your updated balance is: $" + balance);
}
function startATM() {
    while (true) {
        let choice = parseInt(prompt("Welcome to the ATM machine.\n1. Check Balance\n2. Withdraw Money\n3. Deposit Money\n4. Exit"));
        
        switch (choice) {
            case 1:
                checkBalance();
                break;
            case 2:
                let withdrawAmount = parseFloat(prompt("Enter the amount to withdraw:"));
                withdraw(withdrawAmount);
                break;
            case 3:
                let depositAmount = parseFloat(prompt("Enter the amount to deposit:"));
                deposit(depositAmount);
                break;
            case 4:
                console.log("Thank you for using the ATM machine.");
                return;
            default:
                console.log("Invalid choice. Please try again.");
        }
    }
}
startATM();

