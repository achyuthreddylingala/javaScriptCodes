//12.	Create a program that generates the Fibonacci sequence up to a specified number using a while loop.
function generateFibonacci(limit) {
    let fibonacciSeq = [0, 1]; 
    while (fibonacciSeq[fibonacciSeq.length - 1] + fibonacciSeq[fibonacciSeq.length - 2] <= limit) {
        let nextFibonacci = fibonacciSeq[fibonacciSeq.length - 1] + fibonacciSeq[fibonacciSeq.length - 2];
        fibonacciSeq.push(nextFibonacci);
    }

    return fibonacciSeq;
}


let limit = 100; 
let fibonacciSequence = generateFibonacci(limit);
console.log("Fibonacci sequence up to " + limit + ":");
console.log(fibonacciSequence);
