//22.	Write JavaScript code that calculates the power of a number using a for loop.
function calculatePower(base, exponent) {
    let result = 1;
    
    for (let i = 0; i < exponent; i++) { 
        result *= base; 
    }
    return result; 
}
let base = 2; 
let exponent = 3; 
let power = calculatePower(base, exponent);
console.log(base + " raised to the power of " + exponent + " is: " + power);
