//20.	Develop JavaScript code that prints the first N terms of the Fibonacci sequence using a while loop.
//code:
function printFibonacciSeries(N) {
    let firstTerm = 0; // First term of the Fibonacci sequence
    let secondTerm = 1; // Second term of the Fibonacci sequence
    
    let count = 0; 
    console.log("The Fibonacci sequence up to the first " + N + " terms:");  
    while (count < N) {
        console.log(firstTerm);  
        let nextTerm = firstTerm + secondTerm; 
        firstTerm = secondTerm; 
        secondTerm = nextTerm; 
        count++; 
    }
}
printFibonacciSeries(10);

