//23.	Develop a program that finds the GCD (Greatest Common Divisor) of two numbers using a while loop.
//code:
function findGCD(a, b) {
    let remainder, temp;
    if (a < b) {
        temp = a;
        a = b;
        b = temp;
    }
    while (b !== 0) {
        remainder = a % b;
        a = b;
        b = remainder;
    }
    return a;
}
let num1 = 36;
let num2 = 48;
let gcd = findGCD(num1, num2);
console.log("The GCD of " + num1 + " and " + num2 + " is: " + gcd);
