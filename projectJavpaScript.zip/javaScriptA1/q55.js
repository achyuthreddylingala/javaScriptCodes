//Write a program that checks if a given number is a narcissistic prime (a prime number that is also a narcissistic number) using loops and arithmetic operations.
//code:
// Function to check if a number is prime
function isPrime(number) {
    if (number <= 1) {
        return false;
    }
    for (let i = 2; i <= Math.sqrt(number); i++) {
        if (number % i === 0) {
            return false;
        }
    }
    return true;
}

// Function to check if a number is narcissistic
function isNarcissistic(number) {
    const numDigits = String(number).length;
    let sum = 0;
    let temp = number;
    while (temp > 0) {
        const digit = temp % 10;
        sum += Math.pow(digit, numDigits);
        temp = Math.floor(temp / 10);
    }
    return sum === number;
}

// Function to check if a number is a narcissistic prime
function isNarcissisticPrime(number) {
    return isPrime(number) && isNarcissistic(number);
}

// Example usage
const number = 153;
if (isNarcissisticPrime(number)) {
    console.log(number + " is a narcissistic prime.");
} else {
    console.log(number + " is not a narcissistic prime.");
}
