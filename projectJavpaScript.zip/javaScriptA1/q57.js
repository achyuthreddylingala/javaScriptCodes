//Develop a program that calculates the sum of all even Fibonacci numbers up to a given limit.
//code:
function sumOfEvenFibonacci(limit) {
    let prev = 1;
    let curr = 2;
    let sum = 0;

    while (curr <= limit) {
        if (curr % 2 === 0) {
            sum += curr;
        }
        const next = prev + curr;
        prev = curr;
        curr = next;
    }

    return sum;
}

// Example usage
const limit = 4000000; // Given limit
console.log("Sum of even Fibonacci numbers up to", limit, "is:", sumOfEvenFibonacci(limit));

